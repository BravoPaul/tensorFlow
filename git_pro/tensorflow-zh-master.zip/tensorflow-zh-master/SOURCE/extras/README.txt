This directory holds extra files we'd like to be able
to link to and serve from within tensorflow.org
